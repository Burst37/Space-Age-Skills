import ORChat from "@/components/ORChat";
export default function Page() {
  return <ORChat agent="deepseek" label="DeepSeek" accent="#4d6bff" blurb="DeepSeek V4 Pro · primary coding · via OpenRouter" />;
}
