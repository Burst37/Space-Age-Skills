import ORChat from "@/components/ORChat";
export default function Page() {
  return <ORChat agent="gemini" label="Gemini Flash" accent="#4285F4" blurb="Gemini 3.5 Flash · multimodal · long context · via OpenRouter" />;
}
