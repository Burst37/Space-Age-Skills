import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Chat backend for the lightweight model agents.
//  • DeepSeek + Gemini Flash → OpenRouter (one OPENROUTER_API_KEY).
//  • MiniMax → your own MiniMax subscription (OpenAI-compatible API) when
//    MINIMAX_API_KEY is set; otherwise falls back to OpenRouter.
// All endpoints are OpenAI-compatible (/chat/completions), so one call path works.
// Every model slug / base URL is overridable via .env without touching code.
type Cfg = { model: string; baseUrl: string; keyEnv: string };

function resolve(agent: string): Cfg | null {
  switch (agent) {
    case "deepseek":
      return { model: process.env.DEEPSEEK_MODEL || "deepseek/deepseek-v4-pro", baseUrl: "https://openrouter.ai/api/v1", keyEnv: "OPENROUTER_API_KEY" };
    case "gemini":
      return { model: process.env.GEMINI_MODEL || "google/gemini-3.5-flash", baseUrl: "https://openrouter.ai/api/v1", keyEnv: "OPENROUTER_API_KEY" };
    case "minimax":
      if (process.env.MINIMAX_API_KEY) {
        // direct MiniMax subscription
        return { model: process.env.MINIMAX_MODEL || "minimax-m3", baseUrl: process.env.MINIMAX_BASE_URL || "https://api.minimax.io/v1", keyEnv: "MINIMAX_API_KEY" };
      }
      return { model: "minimax/minimax-m3", baseUrl: "https://openrouter.ai/api/v1", keyEnv: "OPENROUTER_API_KEY" };
    default:
      return null;
  }
}

export async function POST(req: NextRequest) {
  let body: { agent?: string; messages?: { role: string; content: string }[] };
  try { body = await req.json(); } catch { return NextResponse.json({ error: "bad request" }, { status: 400 }); }

  const agent = String(body.agent || "");
  const cfg = resolve(agent);
  if (!cfg) return NextResponse.json({ error: `unknown agent "${agent}"` }, { status: 400 });

  const key = process.env[cfg.keyEnv];
  if (!key) {
    return NextResponse.json(
      { error: `${cfg.keyEnv} is not set in the VPS .env — add it and restart.` },
      { status: 200 },
    );
  }

  const messages = Array.isArray(body.messages) ? body.messages : [];
  if (messages.length === 0) return NextResponse.json({ error: "no messages" }, { status: 400 });

  try {
    const r = await fetch(cfg.baseUrl.replace(/\/+$/, "") + "/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://spaceage.os",
        "X-Title": "Space Age OS",
      },
      body: JSON.stringify({ model: cfg.model, messages, temperature: 0.7, max_tokens: 1800 }),
    });
    const j = await r.json();
    if (!r.ok) {
      return NextResponse.json({ error: j?.error?.message || j?.base_resp?.status_msg || `API error (${r.status})`, model: cfg.model }, { status: 200 });
    }
    const reply = j?.choices?.[0]?.message?.content ?? "";
    return NextResponse.json({ reply, model: cfg.model });
  } catch (e) {
    return NextResponse.json({ error: String(e), model: cfg.model }, { status: 200 });
  }
}
