import ORChat from "@/components/ORChat";
export default function Page() {
  return <ORChat agent="minimax" label="MiniMax" accent="#ff5f9e" blurb="MiniMax M3 · long-context · creative · via OpenRouter" />;
}
