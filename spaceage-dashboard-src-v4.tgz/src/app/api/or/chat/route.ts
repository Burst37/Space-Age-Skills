import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// OpenRouter-backed chat for the lightweight model agents (DeepSeek, Gemini
// Flash, MiniMax). One OPENROUTER_API_KEY powers all of them. Each agent's exact
// model slug can be overridden in the VPS .env without touching code.
const MODELS: Record<string, string> = {
  deepseek: process.env.DEEPSEEK_MODEL || "deepseek/deepseek-v4-pro",
  gemini:   process.env.GEMINI_MODEL   || "google/gemini-3.5-flash",
  minimax:  process.env.MINIMAX_MODEL  || "minimax/minimax-m3",
};

export async function POST(req: NextRequest) {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) {
    return NextResponse.json(
      { error: "OPENROUTER_API_KEY is not set in the VPS .env — add it and restart." },
      { status: 200 },
    );
  }

  let body: { agent?: string; messages?: { role: string; content: string }[] };
  try { body = await req.json(); } catch { return NextResponse.json({ error: "bad request" }, { status: 400 }); }

  const agent = String(body.agent || "");
  const model = MODELS[agent];
  if (!model) return NextResponse.json({ error: `unknown agent "${agent}"` }, { status: 400 });

  const messages = Array.isArray(body.messages) ? body.messages : [];
  if (messages.length === 0) return NextResponse.json({ error: "no messages" }, { status: 400 });

  try {
    const r = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://spaceage.os",
        "X-Title": "Space Age OS",
      },
      body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 1800 }),
    });
    const j = await r.json();
    if (!r.ok) {
      return NextResponse.json(
        { error: j?.error?.message || `OpenRouter error (${r.status})`, model },
        { status: 200 },
      );
    }
    const reply = j?.choices?.[0]?.message?.content ?? "";
    return NextResponse.json({ reply, model });
  } catch (e) {
    return NextResponse.json({ error: String(e), model }, { status: 200 });
  }
}
