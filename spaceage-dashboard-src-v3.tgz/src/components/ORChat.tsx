"use client";

import { useRef, useState } from "react";
import { Send, Loader2 } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

// Minimal, real chat surface for the OpenRouter-backed agents (DeepSeek,
// Gemini Flash, MiniMax). Multi-turn: the whole conversation is sent each time.
export default function ORChat({
  agent, label, accent, blurb,
}: { agent: string; label: string; accent: string; blurb: string }) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  async function send() {
    const text = input.trim();
    if (!text || busy) return;
    setErr("");
    const next: Msg[] = [...msgs, { role: "user", content: text }];
    setMsgs(next);
    setInput("");
    setBusy(true);
    try {
      const r = await fetch("/api/or/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agent, messages: next }),
      });
      const j = await r.json();
      if (j.error) setErr(j.error);
      else setMsgs([...next, { role: "assistant", content: j.reply || "(empty reply)" }]);
    } catch (e) {
      setErr(String(e));
    } finally {
      setBusy(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    }
  }

  return (
    <div className="panel panel-hover" style={{ padding: 22, display: "flex", flexDirection: "column", height: "calc(100vh - 230px)", minHeight: 420 }}>
      <div className="flex items-center gap-2.5 mb-4">
        <span className="grid place-items-center w-9 h-9 rounded-lg text-[15px] font-bold"
          style={{ background: `${accent}22`, color: accent, border: `1px solid ${accent}44` }}>
          {label.slice(0, 2)}
        </span>
        <div>
          <div className="text-[14px] font-semibold" style={{ color: "var(--cream)" }}>{label}</div>
          <div className="text-[11px]" style={{ color: "var(--cream-dim)" }}>{blurb}</div>
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto scroll space-y-3 pr-1">
        {msgs.length === 0 && (
          <div className="text-[13px] h-full grid place-items-center text-center px-6" style={{ color: "var(--cream-mute)" }}>
            Ask {label} anything — single line, multi-turn memory. Powered by OpenRouter.
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className="max-w-[80%] rounded-xl px-3.5 py-2.5 text-[13.5px] leading-relaxed whitespace-pre-wrap"
              style={
                m.role === "user"
                  ? { background: `${accent}1f`, border: `1px solid ${accent}3a`, color: "var(--cream)" }
                  : { background: "var(--glass-bg)", border: "1px solid var(--glass-edge)", color: "var(--cream-soft)" }
              }>
              {m.content}
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex items-center gap-2 text-[12px]" style={{ color: "var(--cream-dim)" }}>
            <Loader2 size={13} className="animate-spin" /> {label} is thinking…
          </div>
        )}
        {err && (
          <div className="text-[12px] rounded-lg px-3 py-2" style={{ color: "var(--plum)", background: "rgba(196,96,126,0.08)", border: "1px solid rgba(196,96,126,0.25)" }}>
            {err}
          </div>
        )}
        <div ref={endRef} />
      </div>

      <div className="mt-3 flex items-end gap-2">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); send(); } }}
          placeholder={`Ask ${label}…  (⌘/Ctrl+Enter to send)`}
          rows={2}
          className="flex-1 resize-none rounded-xl px-3.5 py-2.5 text-[13.5px] outline-none"
          style={{ background: "var(--glass-bg)", border: "1px solid var(--glass-edge)", color: "var(--cream)" }}
        />
        <button onClick={send} disabled={busy}
          className="copy-btn shrink-0" style={{ padding: "10px 16px" }}>
          <Send size={14} className="inline -mt-0.5 mr-1" /> Send
        </button>
      </div>
    </div>
  );
}
