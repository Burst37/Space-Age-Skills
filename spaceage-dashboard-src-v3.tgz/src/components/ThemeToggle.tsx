"use client";

import { useEffect, useState } from "react";
import { Sun, Moon } from "lucide-react";

// Flips the whole UI between the dark "liquid glass" theme and the soft
// pastel skeuomorphic "light" theme. Choice is remembered in localStorage and
// applied via <html data-theme="…">. A tiny inline script in layout.tsx sets the
// attribute before paint so there's no flash on load.
export default function ThemeToggle() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const saved = (localStorage.getItem("spaceage.theme") as "dark" | "light") || "dark";
    setTheme(saved);
    document.documentElement.setAttribute("data-theme", saved);
  }, []);

  function toggle() {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.setAttribute("data-theme", next);
    try { localStorage.setItem("spaceage.theme", next); } catch {}
  }

  return (
    <button
      onClick={toggle}
      title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      aria-label="Toggle theme"
      className="theme-toggle grid place-items-center w-9 h-9 rounded-full shrink-0"
    >
      {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  );
}
