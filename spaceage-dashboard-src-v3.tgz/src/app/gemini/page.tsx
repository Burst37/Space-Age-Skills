import ORChat from "@/components/ORChat";
export default function Page() {
  return <ORChat agent="gemini" label="Gemini Flash" accent="#4285F4" blurb="Google Gemini Flash · multimodal · long context · via OpenRouter" />;
}
