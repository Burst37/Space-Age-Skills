# Upstream sources — NOT EMBEDDED IN THIS LITE BUNDLE

This is a portable development handoff, not the finished merged GeoFusion. Download and inspect these source archives/repositories separately before integration.

- GoSom: https://github.com/gosom/google-maps-scraper — supplied original `google-maps-scraper-main.zip`
- Omkar: https://github.com/omkarcloud/google-maps-scraper — supplied original `google-maps-scraper-master.zip`
- Scrapling: https://github.com/D4Vinci/Scrapling
- Agent Reach: https://github.com/Panniantong/Agent-Reach
- Firecrawl: https://github.com/mendableai/firecrawl
- Headroom: https://github.com/headroomlabs-ai/headroom
- Jev: use `references/TypeSafe_Jev_Routing.md` as definitive reference
- Additional token skills: Caveman and Ponytail from Space Age Skills if accessible (not embedded)
- Cinematic Website Builder/Director skills from Space Age Skills Google Drive (not embedded)

The original source ZIPs are available separately in this ChatGPT session if desired. Keep upstream licenses intact if redistributing code.
