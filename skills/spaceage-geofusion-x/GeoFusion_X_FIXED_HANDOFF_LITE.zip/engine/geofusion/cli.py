"""GeoFusion X command line."""
import argparse
import json
from .core import Store,import_file
from .adapters import discover_site,gosom_docker,agent_reach_health,firecrawl_site

def run(argv=None):
    p=argparse.ArgumentParser(prog='geofusion',description='GeoFusion X multi-source research engine')
    p.add_argument('--db',default='geofusion.db')
    sub=p.add_subparsers(dest='cmd',required=True)
    imp=sub.add_parser('import');imp.add_argument('file');imp.add_argument('--source',default='import')
    exp=sub.add_parser('export');exp.add_argument('file');exp.add_argument('--format',choices=['csv','json','jsonl'],default='csv')
    site=sub.add_parser('website');site.add_argument('url');site.add_argument('--engine',choices=['stdlib','scrapling','firecrawl'],default='stdlib')
    maps=sub.add_parser('maps');maps.add_argument('query');maps.add_argument('--depth',type=int,default=1);maps.add_argument('--timeout',type=int,default=600)
    board=sub.add_parser('onboard',help='Interactive configuration wizard; does not scrape')
    board.add_argument('--output',default='geofusion.config.json')
    board.add_argument('--force',action='store_true')
    sub.add_parser('stats');sub.add_parser('doctor');sub.add_parser('records')
    args=p.parse_args(argv);db=Store(args.db)
    if args.cmd=='onboard':
        from .onboarding import questionnaire, save_config
        config=questionnaire()
        print(json.dumps({'config_path':save_config(config,args.output,args.force),'status':'configured_not_executed'},indent=2))
    elif args.cmd=='import':print(json.dumps({'imported':len(import_file(args.file,db,args.source)),**db.stats()}))
    elif args.cmd=='export':print(json.dumps({'exported':db.export(args.file,args.format),'path':args.file}))
    elif args.cmd=='website':
        record=firecrawl_site(args.url) if args.engine=='firecrawl' else discover_site(args.url,args.engine)
        print(json.dumps({'id':db.upsert(record),'record':record},indent=2))
    elif args.cmd=='maps':
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as td:
            path=gosom_docker(args.query,Path(td)/'results.csv',args.depth,args.timeout)
            print(json.dumps({'imported':len(import_file(path,db,'google_maps_gosom')),'stats':db.stats()}))
    elif args.cmd=='stats':print(json.dumps(db.stats(),indent=2))
    elif args.cmd=='records':print(json.dumps(list(db.records()),indent=2))
    elif args.cmd=='doctor':
        import shutil,importlib.util,os
        print(json.dumps({'docker':bool(shutil.which('docker')),'scrapling':bool(importlib.util.find_spec('scrapling')),'firecrawl':bool(importlib.util.find_spec('firecrawl')),'firecrawl_key_set':bool(os.getenv('FIRECRAWL_API_KEY')),'agent_reach':agent_reach_health()},indent=2))
if __name__=='__main__':run()
