# SpaceAge GeoFusion X — Runnable Engineering MVP v0.1

A working, dependency-light orchestration foundation, **not yet a proven enterprise-scale Google Maps/social scraping product**.

## Verified locally

- `python -m geofusion import examples/sample-businesses.jsonl --source demo` — ingest normalized records into SQLite
- `python -m geofusion stats` — unique business and observation counts
- `python -m geofusion export results.csv` — CSV, JSON, or JSONL
- `python -m geofusion website https://example.com` — extract page title, published `mailto:` links, and linked social profiles, when network/site permits
- `python -m geofusion doctor` — check Docker, Scrapling, Firecrawl SDK/key, and Agent Reach CLI
- `python -m unittest discover -s tests -v` — regression tests

Optionally `pip install -e '.[scrapling,firecrawl]'` to use installed third-party connectors. For maps, install Docker first, then `python -m geofusion maps 'coffee shops in Dallas Texas' --depth 1` invokes the documented GoSom Docker collector, imports its CSV, and retains per-observation records. **This has not been live-tested in the build environment.** For social platforms, Agent Reach remains a separately configured upstream channel router; this version diagnoses it and discovers social links on business websites, but does not yet execute authenticated social searches or harvest posts. Respect each platform's terms and applicable rules.

## Source integrations and boundaries

| Source | Current integration | Dependency |
|---|---|---|
| GoSom Google Maps | Real Docker CLI invocation + CSV import | Docker, image, network |
| Omkar Google Maps | Data-format interchange only | No source implementation in supplied archive |
| Scrapling | Real `Fetcher.get()` optional website adapter | `scrapling` package |
| Firecrawl | Optional official SDK `scrape()` adapter | `firecrawl-py`, API key |
| Agent Reach | Real `agent-reach doctor` health check | Installed/configured CLI; social search not yet wired |
| Ponytail / Caveman / Headroom | Deferred to separate token layer | Original skill files and benchmarks needed |

## Production roadmap

1. Add robust source-specific field mapping for GoSom JSON and streamed job ingestion.
2. Add authenticated Agent Reach channel execution using approved commands and credential isolation.
3. Develop high-volume queue workers, checkpoint/retry logic, structured telemetry, per-domain policies and API limits.
4. Implement entity-resolution graph across multiple sources, branch-aware matching, and human review for uncertain matches.
5. Add public social analytics, historical change detection, spatial search/PostGIS and dashboard/API.
6. Benchmark against reproducible fixtures and live authorized targets. Track accuracy, completeness, throughput, duplicates and cost.

**Provenance:** upstream sources are not vendored or modified. See `UPSTREAM.md`. Local MVP functionality is original integration code.

## New: onboarding wizard

Run `python -m geofusion onboard` before collecting. This saves a non-secret `geofusion.config.json` job profile and does not launch scraping. Authentication setup for Agent Reach remains a separate, unimplemented integration.

### Multiple selections in onboarding
Objectives, platforms and access methods accept comma-separated choices (e.g. `business,social` and `public,authorized_session`). Authorization confirmation applies to any authenticated/API access. The wizard never starts collection.

## v0.4 platform onboarding

The wizard now offers 71 selectable platform IDs across 7 categories and accepts `custom:<name>`. Catalog listing does not establish that a live connector is installed or that collection is permitted. Each saved configuration includes `platform_readiness`.
