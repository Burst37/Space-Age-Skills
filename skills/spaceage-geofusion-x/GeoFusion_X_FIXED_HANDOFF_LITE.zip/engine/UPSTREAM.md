# External components
- GoSom: https://github.com/gosom/google-maps-scraper — MIT (source supplied in prior upload).
- Omkar: https://github.com/omkarcloud/google-maps-scraper — documentation-only upload; no local integration of implementation.
- Scrapling: https://github.com/D4Vinci/Scrapling — BSD-3-Clause.
- Agent Reach: https://github.com/Panniantong/Agent-Reach — MIT.
- Firecrawl: https://github.com/mendableai/firecrawl — check current component license and API terms before deployment.
- Headroom: https://github.com/headroomlabs-ai/headroom — token-context layer, not bundled.
Adapters rely on separately installed components; no upstream code is repackaged in this archive. Preserve applicable third-party attribution on distribution.
